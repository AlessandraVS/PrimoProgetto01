# Questo è il primo progetto del corso di Software Engineeering

Lo scopo di questo progetto è quello di imparare l'uso di _Git/Github_ e scrivere i **requisiti**